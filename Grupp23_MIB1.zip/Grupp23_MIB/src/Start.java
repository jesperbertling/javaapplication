    
import javax.swing.JOptionPane;
import oru.inf.InfDB;
import oru.inf.InfException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author axelr
 */
public class Start {

    private static InfDB idb;
    
    
    public static void main(String[] args)
    {
        try
        {
           idb = new InfDB("mibdb", "3306", "mibdba", "mibkey"); 
           
        }
        
        catch(InfException ettUndantag)
        {
            JOptionPane.showMessageDialog(null, "Något gick fel");
            System.out.println("Internt felmeddelande" + ettUndantag.getMessage());
        }   
        new PickLogIn(idb).setVisible(true);
        
    }
}
