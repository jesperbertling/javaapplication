import oru.inf.InfDB;
import oru.inf.InfException;
import javax.swing.JOptionPane;
import java.awt.event.WindowEvent;
import java.awt.Toolkit;


public class AgentLogin extends javax.swing.JFrame {

    private InfDB idb;
    private static String namnet;
  
    public AgentLogin(InfDB idb) {
        initComponents();
        this.idb = idb;
     }
       

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblRubrik = new javax.swing.JLabel();
        btnVisaNamn = new javax.swing.JButton();
        tfAngivetID = new javax.swing.JTextField();
        lblAngeID = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPassword = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblRubrik.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        lblRubrik.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRubrik.setText("Agent Login");
        lblRubrik.setOpaque(true);

        btnVisaNamn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnVisaNamn.setText("Login");
        btnVisaNamn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVisaNamnActionPerformed(evt);
            }
        });

        lblAngeID.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lblAngeID.setText("CodeName");

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel1.setText("Password");

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAngeID, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)
                                .addComponent(btnVisaNamn, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(90, 90, 90)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfAngivetID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addComponent(lblRubrik, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(86, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lblRubrik, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tfAngivetID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAngeID))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVisaNamn)
                    .addComponent(jButton1))
                .addGap(30, 30, 30))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
    Denna klass gör att som agent kan du logga in i systemet med ett bestämt lösenord och ett användarnamn, 
    * skriver man in fel lösenord så kommer man inte in i systemet.
    **/

    private void btnVisaNamnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVisaNamnActionPerformed
               
               
        if(Valdering.textFaltHarVarde(tfAngivetID) )
         try 
        {
                String namn = tfAngivetID.getText();
                namnet = namn;
                String fraga1 = "select namn from agent where namn = '" + namn +"'";
                String svar1 = idb.fetchSingle(fraga1);
                String resultat1 = svar1;   
            
                String losenord = jPassword.getText();
                String fraga2 = "select losenord from agent where namn = '" + namn +"'";
                String svar2 = idb.fetchSingle(fraga2);
                String resultat2 = svar2;
                
                
                
                if(Valdering.textFaltHarVarde(tfAngivetID) && Valdering.losenordHarVarde(jPassword))
                {
                    if(  namn.equals(resultat1) && losenord.equals(resultat2))
                        {
                            
                            MainWindowAgent fonster = new MainWindowAgent(idb);
                            fonster.setVisible(true);
                            close();
                        }
                    else
                    {
                    JOptionPane.showConfirmDialog(null, "Wrong code name or password");
                    }
                }
        }
        catch(InfException e)
            {
                JOptionPane.showConfirmDialog(null, "Något gick fel!");
                System.out.println("Internt felmeddelande" + e.getMessage());
            }    
                
    }    
    public void close()
    {
        WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
               
    }//GEN-LAST:event_btnVisaNamnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        PickLogIn fonster = new PickLogIn(idb);
        fonster.setVisible(true);
        close();
        
    }//GEN-LAST:event_jButton1ActionPerformed
    
    public static String getNamn()
    {
        return namnet;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVisaNamn;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPasswordField jPassword;
    private javax.swing.JLabel lblAngeID;
    private javax.swing.JLabel lblRubrik;
    private javax.swing.JTextField tfAngivetID;
    // End of variables declaration//GEN-END:variables

   
}

    //    String user = namn.getText();
    //    String pW = password.getText();
        
      //  try{
        
        
            
      //  String us =databas.fetchSingel("select Administrator from agent where Administrator = 'J'");
        //String sql = databas.
        //if (user.contians(usernamn)){
            
        
        
       // catch(InfException ex){
       //     System.out.print(ex.getMessage());
       //     JOptionPane.showMessageDialog(null,"Uräskta något blev fel");
        

