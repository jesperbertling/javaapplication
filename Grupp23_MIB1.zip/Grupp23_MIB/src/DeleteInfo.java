import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import oru.inf.InfDB;
import oru.inf.InfException;


public class DeleteInfo extends javax.swing.JFrame {

    private InfDB idb;
    
    public DeleteInfo(InfDB idb) {
        initComponents();
        this.idb = idb;
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        comboBox = new javax.swing.JComboBox<>();
        txtID = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        comboBox.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        comboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alien", "Utrustning", "Agent" }));

        txtID.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Delete");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel1.setText("Category");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("ID");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setText("Delete");

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setText("Close");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(126, 126, 126))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(30, 30, 30)
                .addComponent(jButton2)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

/** Denna klass gör att du som inloggad administratör kan ta bort alien eller utrustning eller agent ur system
*/

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Object selectedItem = comboBox.getSelectedItem();
        String selectedItemStr = selectedItem.toString();
        String svar = txtID.getText();
      
       try {
           if(Valdering.textFaltHarVarde(txtID) && Valdering.isHeltal(txtID))
           {
           if (selectedItem.equals("Alien"))
            {
                String deleteAlien1 = "Delete from Alien where Alien_ID = " + svar;
                String deleteAlien2 = "Delete from boglodite where Alien_ID =" + svar;
                String deleteAlien3 = "Delete from squid where Alien_ID =" + svar;
                String deleteAlien4 = "Delete from Worm where Alien_ID =" + svar;
                idb.delete(deleteAlien2);
                idb.delete(deleteAlien3);
                idb.delete(deleteAlien4);
                idb.delete(deleteAlien1);
                JOptionPane.showMessageDialog(null, "Deleted");
               
            }
           if (selectedItem.equals("Utrustning"))
           {
               String deleteEquipment1= "Delete from Utrustning where Utrustnings_ID = "+ svar;
               String deleteEquipment2= "Delete from Innehar_Utrustning where Utrustnings_ID = " +svar;
               String deleteEquipment3= "Delete from Vapen where Utrustnings_ID = " + svar;
               String deleteEquipment4 = "Delete from Teknik where Utrustnings_ID =" + svar;
               String deleteEquipment5 = "Delete from Kommunikation where Utrustnings_ID =" + svar;
               idb.delete(deleteEquipment2);
               idb.delete(deleteEquipment3);
               idb.delete(deleteEquipment4);
               idb.delete(deleteEquipment5);
               idb.delete(deleteEquipment1);
                JOptionPane.showMessageDialog(null, "Deleted");
               
           }
           if (selectedItem.equals("Agent"))
           {
               String deleteAgent1 = "Delete from Agent where Agent_ID =" + svar;
               String deleteAgent2="Delete from Alien where Ansvarig_agent =" + svar;
               String deleteAgent3="Delete from Faltagent where Agent_ID = "+ svar;
               String deleteAgent4="Delete from innehar_fordon where Agent_ID = " +svar;
               String deleteAgent5="Delete from innehar_utrustning where Agent_Id =" + svar;
               String deleteAgent6="Delete from omradeschef where Agent_ID = " + svar;
               String deleteAgent7="Delete from kontorsChef where Agent_ID = " + svar;
               idb.delete(deleteAgent7);
               idb.delete(deleteAgent2);
               idb.delete(deleteAgent3);
               idb.delete(deleteAgent4);
               idb.delete(deleteAgent5);
               idb.delete(deleteAgent6);
               idb.delete(deleteAgent1);
               
               JOptionPane.showMessageDialog(null, "Deleted");
           }
           }
           else
           {
              JOptionPane.showMessageDialog(null, "ID only accept numbers"); 
           }
        }
       
        catch (InfException ettUndantag){
        JOptionPane.showMessageDialog(null,"Something went wrong!");
        System.out.println ("Internt felmedelande" + ettUndantag.getMessage()); 
       
       
    } 
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        close();
    }//GEN-LAST:event_jButton2ActionPerformed

    public void close()
    {
        WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
               
    }   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboBox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField txtID;
    // End of variables declaration//GEN-END:variables
}
