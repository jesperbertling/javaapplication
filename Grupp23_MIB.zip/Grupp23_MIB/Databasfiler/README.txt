Förklaringar för vad de olika filerna gör

* mibdb_komplett.sql
Skript som ska köras i Datagrip så att databasen “mibdb” skapas och kan användas

* InfDB.jar
Klasser för att kunna hantera databasfrågor i Netbeans. Ska importeras till projektets library via Netbeans

* mysql-connector-java-8.0.23.jar
Connectorn som ska användas när man skapar en ny databasanslutning i Netbeans. Ska också importeras till projektets library via Netbeans

* javadoc_InfDB.zip
Dokumentation för InfDB.jar för att beskriva vad dess metoder gör (inte nödvändig men bra stöd)
