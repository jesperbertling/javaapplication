
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import oru.inf.InfDB;
import oru.inf.InfException;

public class Valdering {
    private static InfDB idb;
    public Valdering(InfDB idb)
    {
        this.idb = idb;
    }
    
    public static boolean textFaltHarVarde(JTextField rutaAttKolla)
    {
        boolean resultat = true;
        
        if(rutaAttKolla.getText().isEmpty())
        {
            JOptionPane.showConfirmDialog(null, "Text field needs value");
            resultat = false;
            rutaAttKolla.requestFocus();
        }
         
        
        return resultat;
    }
    
    public static boolean isHeltal(JTextField rutaAttKolla)
    {
        boolean resultat = true;
        
        try
        {
            String enStrang = rutaAttKolla.getText();
            Integer.parseInt(enStrang);
            rutaAttKolla.requestFocus();
            
        }
        catch(NumberFormatException e)
        {

            resultat = false;
            JOptionPane.showConfirmDialog(null, "ID requires only number");
        }
        
        return resultat;
    }
    
    public static boolean losenordHarVarde(JPasswordField rutaAttKolla)
    {
        boolean resultat = true;
        
        if(rutaAttKolla.getText().isEmpty())
        {
            JOptionPane.showConfirmDialog(null, "Text field needs value");
            resultat = false;
            rutaAttKolla.requestFocus();
        }
         
        
        return resultat;
    }
    }
    

   